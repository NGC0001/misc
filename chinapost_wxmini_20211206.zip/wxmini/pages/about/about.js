// about.js
const app = getApp()

Page({
  bindShareTap: function(e) {
    console.log("Share")
  },
  onLoad() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
    })
  },
})
