// pages/service/service.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    servicelist: [
      { id: 0, imgsrc: "images/order.jpg", name: "在线下单", url: "../order/order" },
      { id: 1, imgsrc: "images/mail_lookup.webp", name: "邮件查询", url: "../lookup/lookup" },
      { id: 2, imgsrc: "images/fee_timeliness.webp", name: "运费时效", url: "../fee/fee" },
      { id: 3, imgsrc: "images/introduction.webp", name: "产品介绍", url: "../intro/intro" },
      { id: 4, imgsrc: "images/customer_service.webp", name: "微客服", url: "../customerserv/customerserv" },
      { id: 5, imgsrc: "images/claim.jpg", name: "自助理赔", url: "../claim/claim" },
    ],
  },
  // 事件处理函数
  bindServiceTap: function(e) {
    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  },
  onLoad() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'],
    })
  },
})